<div class="elemento">
  <div class="row">
    <div class="sub-header clearfix">
      <!--<img src="./Images/logo-ind.png">-->
      <div class="datos">
        <div class="nombre">
          <p class="sec-titulo"><span class="gris">Bienvenid@</span> <b><?php echo $nombre; ?></b></p>
        </div>
        <div class="saldo">
          <p class="sec-titulo">Tus puntos</p>
          <p class="sec-pts"><?php echo $puntosClienteF; ?></p>
        </div>
      </div>
      <div class="rank">
        <p class="rank-reg"><span>Top Regional 25</span>/<span>50</span></p>
        <p class="rank-nac"><span>Top Nacional 400</span>/<span>1400</span></p>
        <p class="rank-cedis"><span>Top CEDIS 12</span>/<span>25</span></p>
      </div>
    </div>
    <hr>
  </div>
</div>