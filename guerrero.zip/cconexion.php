<?php

	$mysqli->close();

?>